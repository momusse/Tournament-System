﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectfiver
{
    

    public partial class Form1 : System.Windows.Forms.Form

    {
      private int totalTeamScore = 0;

        
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("Are you sure you want to exit?", "Tournament System", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            DialogResult iReset;
            iReset = MessageBox.Show("Are you sure you want to reset?", "Tournament System", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (iReset == DialogResult.Yes)
            {
                chkmentalmath.Checked = false;
                chkLongJump.Checked = false;
                chkRunning.Checked = false;
                chkshotput.Checked = false;
                chkSwimming.Checked = false;

                chktm1pl1.Checked = false;
                chktm1pl2.Checked = false;
                chktm1pl3.Checked = false;
                chktm1pl4.Checked = false;
                chktm1pl5.Checked = false;

                chktm2pl1.Checked = false;
                chktm2pl2.Checked = false;
                chktm2pl3.Checked = false;
                chktm2pl4.Checked = false;
                chktm2pl5.Checked = false;

                chktm3pl1.Checked = false;
                chktm3pl2.Checked = false;
                chktm3pl3.Checked = false;
                chktm3pl4.Checked = false;
                chktm3pl5.Checked = false;

                chktm4pl1.Checked = false;
                chktm4pl2.Checked = false;
                chktm4pl3.Checked = false;
                chktm4pl4.Checked = false;
                chktm4pl5.Checked = false;

                lblt1ts.Text = null;
                lblt2ts.Text = null;
                lblt3ts.Text = null;
                lblt4ts.Text = null;
                lblOutput.Text=null;
            }

        } private void UpdateTotalScore()
        {
      totalTeamScore = 0;

            CheckBox[] gameCheckboxes = { chkRunning, chkLongJump, chkSwimming, chkmentalmath, chkshotput };

            int selectedGameIndex = -1;
            for (int i = 0; i < gameCheckboxes.Length; i++)
            {
                if (gameCheckboxes[i].Checked)
                {
                    selectedGameIndex = i;
                    break;
                }
            }
        }
private void chktm1pl1_CheckedChanged(object sender, EventArgs e)
        {
               UpdateTotalScore1();
        }

        private void chktm1pl2_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotalScore1();
        }
        private void chkLongJump_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotalScore1();
        }

        private void lblt1ts_Click(object sender, EventArgs e)
        {

        }

        private void chktm1pl3_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotalScore1();
        }

        private void chktm1pl4_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotalScore1();

        }

        private void chktm1pl5_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotalScore1();
        }


        private void chktm2pl1_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotalScore2();

        }

        private void chktm2pl2_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotalScore2();

        }

        private void chktm2pl3_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotalScore2();
        }

        private void chktm2pl4_CheckedChanged(object sender, EventArgs e)
        {

            UpdateTotalScore2();
        }

        private void chktm2pl5_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotalScore2();
        }

        private void chktm3pl1_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotalScore3();
        }

        private void chktm3pl2_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotalScore3();
        }

        private void chktm3pl3_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotalScore3();
        }

        private void chktm3pl4_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotalScore3();
        }

        private void chktm3pl5_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotalScore3();
        }

        private void chktm4pl1_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotalScore4();
        }

        private void chktm4pl2_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotalScore4();
        }

        private void chktm4pl3_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotalScore4();
        }

        private void chktm4pl4_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotalScore4();
        }

        private void chktm4pl5_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotalScore4();

        }


        private void chkRunning_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotalScore1();
            UpdateTotalScore2();
            UpdateTotalScore3();
            UpdateTotalScore4();
        }

        private void chkSwimming_CheckedChanged(object sender, EventArgs e)
        {
            UpdateTotalScore1();
            UpdateTotalScore2();
            UpdateTotalScore3();
            UpdateTotalScore4();
        }

        private void chkmentalmath_CheckedChanged(object sender, EventArgs e)
        {

            UpdateTotalScore1();
            UpdateTotalScore2();
            UpdateTotalScore3();
            UpdateTotalScore4();
        }

        private void chkshotput_CheckedChanged(object sender, EventArgs e)
        {

            UpdateTotalScore1();
            UpdateTotalScore2();
            UpdateTotalScore3();
            UpdateTotalScore4();
        }
        private void UpdateTotalScore1()
        {
                   
                    int totalTeamScore1 = 0;

                              CheckBox[] gameCheckboxes = { chkRunning, chkLongJump, chkSwimming, chkmentalmath, chkshotput };
                              int[] gamePoints = { 24,12,36,24,24 };

                              
                              CheckBox[] playerCheckboxes = { chktm1pl1, chktm1pl2, chktm1pl3, chktm1pl4, chktm1pl5 };

                              
                              int selectedGameIndex = -1;
                              for (int i = 0; i < gameCheckboxes.Length; i++)
                              {
                                  if (gameCheckboxes[i].Checked)
                                  {
                                      selectedGameIndex = i;
                                      break;
                                  }
                              }

                              
                              if (selectedGameIndex >= 0)
                              {
                                  for (int j = 0; j < playerCheckboxes.Length; j++)
                                  {
                                      if (playerCheckboxes[j].Checked)
                                      {
                                          totalTeamScore1 += gamePoints[selectedGameIndex];
                                      }
                                  }
                              }

                              lblt1ts.Text = totalTeamScore1.ToString();
      
    }
        


        private void UpdateTotalScore2()
        {
            int totalTeamScore2 = 0;

            CheckBox[] gameCheckboxes = { chkRunning, chkLongJump, chkSwimming, chkmentalmath, chkshotput };
            int[] gamePoints = { 24, 12, 36, 24, 24 };

            CheckBox[] playerCheckboxes = { chktm2pl1, chktm2pl2, chktm2pl3, chktm2pl4, chktm2pl5 };

            int selectedGameIndex = -1;
            for (int i = 0; i < gameCheckboxes.Length; i++)
            {
                if (gameCheckboxes[i].Checked)
                {
                    selectedGameIndex = i;
                    break;
                }
            }

            if (selectedGameIndex >= 0)
            {
                for (int j = 0; j < playerCheckboxes.Length; j++)
                {
                    if (playerCheckboxes[j].Checked)
                    {
                        totalTeamScore2 += gamePoints[selectedGameIndex];
                    }
                }
            }

            lblt2ts.Text = totalTeamScore2.ToString();
        }

        private void UpdateTotalScore3()
        {
            int totalTeamScore3 = 0;

            CheckBox[] gameCheckboxes = { chkRunning, chkLongJump, chkSwimming, chkmentalmath, chkshotput };
            int[] gamePoints = { 24, 12, 36, 24, 24 };

            CheckBox[] playerCheckboxes = { chktm3pl1, chktm3pl2, chktm3pl3, chktm3pl4, chktm3pl5 };

            int selectedGameIndex = -1;
            for (int i = 0; i < gameCheckboxes.Length; i++)
            {
                if (gameCheckboxes[i].Checked)
                {
                    selectedGameIndex = i;
                    break;
                }
            }

            if (selectedGameIndex >= 0)
            {
                for (int j = 0; j < playerCheckboxes.Length; j++)
                {
                    if (playerCheckboxes[j].Checked)
                    {
                        totalTeamScore3 += gamePoints[selectedGameIndex];
                    }
                }
            }

            lblt3ts.Text = totalTeamScore3.ToString();

        }
        private void UpdateTotalScore4()
        {
            int totalTeamScore4 = 0;

            CheckBox[] gameCheckboxes = { chkRunning, chkLongJump, chkSwimming, chkmentalmath, chkshotput };
            int[] gamePoints = { 24, 12, 36, 24, 24 };

            CheckBox[] playerCheckboxes = { chktm4pl1, chktm4pl2, chktm4pl3, chktm4pl4, chktm4pl5 };

            int selectedGameIndex = -1;
            for (int i = 0; i < gameCheckboxes.Length; i++)
            {
                if (gameCheckboxes[i].Checked)
                {
                    selectedGameIndex = i;
                    break;
                }
            }

            if (selectedGameIndex >= 0)
            {
                for (int j = 0; j < playerCheckboxes.Length; j++)
                {
                    if (playerCheckboxes[j].Checked)
                    {
                        totalTeamScore4 += gamePoints[selectedGameIndex];
                    }
                }
            }

            lblt4ts.Text = totalTeamScore4.ToString();
        }

        private void btnOverallPoints_Click(object sender, EventArgs e)
        {
            if (int.TryParse(lblt1ts.Text, out int score1) &&
                int.TryParse(lblt2ts.Text, out int score2) &&
                int.TryParse(lblt3ts.Text, out int score3) &&
                int.TryParse(lblt4ts.Text, out int score4))
            {
                string total = (score1 + score2 + score3 + score4).ToString();

                lblOutput.Text = total;
            }
            else
            {
                lblOutput.Text = "Invalid scores";
            }
        }

        private void lblRunning_Click(object sender, EventArgs e)
        {

        }

        private void btnIndividual_Click(object sender, EventArgs e)
        {
            Individual indiv = new Individual();

            indiv.ShowDialog();


        }
    }
}




