﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectfiver
{
    public partial class Individual : System.Windows.Forms.Form
    {
        public Individual()
        {
            InitializeComponent();
        }
    }
}
