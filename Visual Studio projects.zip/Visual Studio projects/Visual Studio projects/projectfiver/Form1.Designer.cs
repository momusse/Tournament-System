﻿namespace projectfiver
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.TotalPoints = new System.Windows.Forms.GroupBox();
            this.lblOutput = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnOverallPoints = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblshotput = new System.Windows.Forms.Label();
            this.lblmentalmath = new System.Windows.Forms.Label();
            this.lblSwimming = new System.Windows.Forms.Label();
            this.lblLongJump = new System.Windows.Forms.Label();
            this.lblRunning = new System.Windows.Forms.Label();
            this.chkshotput = new System.Windows.Forms.CheckBox();
            this.chkmentalmath = new System.Windows.Forms.CheckBox();
            this.chkSwimming = new System.Windows.Forms.CheckBox();
            this.chkLongJump = new System.Windows.Forms.CheckBox();
            this.chkRunning = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chktm1pl5 = new System.Windows.Forms.CheckBox();
            this.chktm1pl4 = new System.Windows.Forms.CheckBox();
            this.chktm1pl3 = new System.Windows.Forms.CheckBox();
            this.chktm1pl2 = new System.Windows.Forms.CheckBox();
            this.chktm1pl1 = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.chktm2pl5 = new System.Windows.Forms.CheckBox();
            this.chktm2pl4 = new System.Windows.Forms.CheckBox();
            this.chktm2pl3 = new System.Windows.Forms.CheckBox();
            this.chktm2pl2 = new System.Windows.Forms.CheckBox();
            this.chktm2pl1 = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.chktm3pl5 = new System.Windows.Forms.CheckBox();
            this.chktm3pl4 = new System.Windows.Forms.CheckBox();
            this.chktm3pl3 = new System.Windows.Forms.CheckBox();
            this.chktm3pl2 = new System.Windows.Forms.CheckBox();
            this.chktm3pl1 = new System.Windows.Forms.CheckBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.chktm4pl5 = new System.Windows.Forms.CheckBox();
            this.chktm4pl4 = new System.Windows.Forms.CheckBox();
            this.chktm4pl3 = new System.Windows.Forms.CheckBox();
            this.chktm4pl2 = new System.Windows.Forms.CheckBox();
            this.chktm4pl1 = new System.Windows.Forms.CheckBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.lbltotalpoints = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.lblt1ts = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.lblt2ts = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.lblt3ts = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.lblt4ts = new System.Windows.Forms.Label();
            this.btnIndividual = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.TotalPoints.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkCyan;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1408, 100);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Coral;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, -14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1499, 114);
            this.label1.TabIndex = 2;
            this.label1.Text = "Tournament System";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 642);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1408, 183);
            this.panel2.TabIndex = 1;
            // 
            // TotalPoints
            // 
            this.TotalPoints.BackColor = System.Drawing.Color.ForestGreen;
            this.TotalPoints.Controls.Add(this.lblOutput);
            this.TotalPoints.Controls.Add(this.btnExit);
            this.TotalPoints.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalPoints.Location = new System.Drawing.Point(3, 564);
            this.TotalPoints.Name = "TotalPoints";
            this.TotalPoints.Size = new System.Drawing.Size(1391, 261);
            this.TotalPoints.TabIndex = 0;
            this.TotalPoints.TabStop = false;
            this.TotalPoints.Text = "Total Points";
            // 
            // lblOutput
            // 
            this.lblOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOutput.Location = new System.Drawing.Point(55, 66);
            this.lblOutput.Name = "lblOutput";
            this.lblOutput.Size = new System.Drawing.Size(225, 42);
            this.lblOutput.TabIndex = 3;
            this.lblOutput.Text = "--";
            this.lblOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(920, 153);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(435, 91);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnReset
            // 
            this.btnReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.Location = new System.Drawing.Point(1126, 236);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(250, 110);
            this.btnReset.TabIndex = 6;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnOverallPoints
            // 
            this.btnOverallPoints.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOverallPoints.Location = new System.Drawing.Point(1126, 117);
            this.btnOverallPoints.Name = "btnOverallPoints";
            this.btnOverallPoints.Size = new System.Drawing.Size(250, 113);
            this.btnOverallPoints.TabIndex = 7;
            this.btnOverallPoints.Text = "Overall Points";
            this.btnOverallPoints.UseVisualStyleBackColor = true;
            this.btnOverallPoints.Click += new System.EventHandler(this.btnOverallPoints_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.AutoSize = true;
            this.groupBox2.BackColor = System.Drawing.Color.Plum;
            this.groupBox2.Controls.Add(this.lblshotput);
            this.groupBox2.Controls.Add(this.lblmentalmath);
            this.groupBox2.Controls.Add(this.lblSwimming);
            this.groupBox2.Controls.Add(this.lblLongJump);
            this.groupBox2.Controls.Add(this.lblRunning);
            this.groupBox2.Controls.Add(this.chkshotput);
            this.groupBox2.Controls.Add(this.chkmentalmath);
            this.groupBox2.Controls.Add(this.chkSwimming);
            this.groupBox2.Controls.Add(this.chkLongJump);
            this.groupBox2.Controls.Add(this.chkRunning);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(3, 106);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(302, 282);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Events                  Points";
            // 
            // lblshotput
            // 
            this.lblshotput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblshotput.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblshotput.Location = new System.Drawing.Point(171, 217);
            this.lblshotput.Name = "lblshotput";
            this.lblshotput.Size = new System.Drawing.Size(118, 40);
            this.lblshotput.TabIndex = 1;
            this.lblshotput.Text = "24";
            this.lblshotput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblmentalmath
            // 
            this.lblmentalmath.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblmentalmath.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmentalmath.Location = new System.Drawing.Point(171, 171);
            this.lblmentalmath.Name = "lblmentalmath";
            this.lblmentalmath.Size = new System.Drawing.Size(118, 40);
            this.lblmentalmath.TabIndex = 1;
            this.lblmentalmath.Text = "24";
            this.lblmentalmath.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSwimming
            // 
            this.lblSwimming.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSwimming.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSwimming.Location = new System.Drawing.Point(171, 129);
            this.lblSwimming.Name = "lblSwimming";
            this.lblSwimming.Size = new System.Drawing.Size(118, 40);
            this.lblSwimming.TabIndex = 1;
            this.lblSwimming.Text = "36";
            this.lblSwimming.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLongJump
            // 
            this.lblLongJump.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblLongJump.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLongJump.Location = new System.Drawing.Point(171, 86);
            this.lblLongJump.Name = "lblLongJump";
            this.lblLongJump.Size = new System.Drawing.Size(118, 40);
            this.lblLongJump.TabIndex = 1;
            this.lblLongJump.Text = "12";
            this.lblLongJump.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblRunning
            // 
            this.lblRunning.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRunning.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRunning.Location = new System.Drawing.Point(171, 40);
            this.lblRunning.Name = "lblRunning";
            this.lblRunning.Size = new System.Drawing.Size(118, 40);
            this.lblRunning.TabIndex = 1;
            this.lblRunning.Text = "24";
            this.lblRunning.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblRunning.Click += new System.EventHandler(this.lblRunning_Click);
            // 
            // chkshotput
            // 
            this.chkshotput.AutoSize = true;
            this.chkshotput.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkshotput.Location = new System.Drawing.Point(24, 217);
            this.chkshotput.Name = "chkshotput";
            this.chkshotput.Size = new System.Drawing.Size(93, 28);
            this.chkshotput.TabIndex = 0;
            this.chkshotput.Text = "Shotput";
            this.chkshotput.UseVisualStyleBackColor = true;
            this.chkshotput.CheckedChanged += new System.EventHandler(this.chkshotput_CheckedChanged);
            // 
            // chkmentalmath
            // 
            this.chkmentalmath.AutoSize = true;
            this.chkmentalmath.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkmentalmath.Location = new System.Drawing.Point(24, 168);
            this.chkmentalmath.Name = "chkmentalmath";
            this.chkmentalmath.Size = new System.Drawing.Size(131, 28);
            this.chkmentalmath.TabIndex = 0;
            this.chkmentalmath.Text = "Mental Math";
            this.chkmentalmath.UseVisualStyleBackColor = true;
            this.chkmentalmath.CheckedChanged += new System.EventHandler(this.chkmentalmath_CheckedChanged);
            // 
            // chkSwimming
            // 
            this.chkSwimming.AutoSize = true;
            this.chkSwimming.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkSwimming.Location = new System.Drawing.Point(24, 126);
            this.chkSwimming.Name = "chkSwimming";
            this.chkSwimming.Size = new System.Drawing.Size(117, 28);
            this.chkSwimming.TabIndex = 0;
            this.chkSwimming.Text = "Swimming";
            this.chkSwimming.UseVisualStyleBackColor = true;
            this.chkSwimming.CheckedChanged += new System.EventHandler(this.chkSwimming_CheckedChanged);
            // 
            // chkLongJump
            // 
            this.chkLongJump.AutoSize = true;
            this.chkLongJump.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkLongJump.Location = new System.Drawing.Point(24, 83);
            this.chkLongJump.Name = "chkLongJump";
            this.chkLongJump.Size = new System.Drawing.Size(124, 28);
            this.chkLongJump.TabIndex = 0;
            this.chkLongJump.Text = "Long Jump";
            this.chkLongJump.UseVisualStyleBackColor = true;
            this.chkLongJump.CheckedChanged += new System.EventHandler(this.chkLongJump_CheckedChanged);
            // 
            // chkRunning
            // 
            this.chkRunning.AutoSize = true;
            this.chkRunning.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkRunning.Location = new System.Drawing.Point(24, 40);
            this.chkRunning.Name = "chkRunning";
            this.chkRunning.Size = new System.Drawing.Size(101, 28);
            this.chkRunning.TabIndex = 0;
            this.chkRunning.Text = "Running";
            this.chkRunning.UseVisualStyleBackColor = true;
            this.chkRunning.CheckedChanged += new System.EventHandler(this.chkRunning_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.AutoSize = true;
            this.groupBox1.BackColor = System.Drawing.Color.Plum;
            this.groupBox1.Controls.Add(this.chktm1pl5);
            this.groupBox1.Controls.Add(this.chktm1pl4);
            this.groupBox1.Controls.Add(this.chktm1pl3);
            this.groupBox1.Controls.Add(this.chktm1pl2);
            this.groupBox1.Controls.Add(this.chktm1pl1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(317, 106);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(245, 316);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Team 1";
            // 
            // chktm1pl5
            // 
            this.chktm1pl5.AutoSize = true;
            this.chktm1pl5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chktm1pl5.Location = new System.Drawing.Point(22, 240);
            this.chktm1pl5.Name = "chktm1pl5";
            this.chktm1pl5.Size = new System.Drawing.Size(152, 33);
            this.chktm1pl5.TabIndex = 0;
            this.chktm1pl5.Text = "PLAYER 5";
            this.chktm1pl5.UseVisualStyleBackColor = true;
            this.chktm1pl5.CheckedChanged += new System.EventHandler(this.chktm1pl5_CheckedChanged);
            // 
            // chktm1pl4
            // 
            this.chktm1pl4.AutoSize = true;
            this.chktm1pl4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chktm1pl4.Location = new System.Drawing.Point(22, 188);
            this.chktm1pl4.Name = "chktm1pl4";
            this.chktm1pl4.Size = new System.Drawing.Size(152, 33);
            this.chktm1pl4.TabIndex = 0;
            this.chktm1pl4.Text = "PLAYER 4";
            this.chktm1pl4.UseVisualStyleBackColor = true;
            this.chktm1pl4.CheckedChanged += new System.EventHandler(this.chktm1pl4_CheckedChanged);
            // 
            // chktm1pl3
            // 
            this.chktm1pl3.AutoSize = true;
            this.chktm1pl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chktm1pl3.Location = new System.Drawing.Point(22, 142);
            this.chktm1pl3.Name = "chktm1pl3";
            this.chktm1pl3.Size = new System.Drawing.Size(152, 33);
            this.chktm1pl3.TabIndex = 0;
            this.chktm1pl3.Text = "PLAYER 3";
            this.chktm1pl3.UseVisualStyleBackColor = true;
            this.chktm1pl3.CheckedChanged += new System.EventHandler(this.chktm1pl3_CheckedChanged);
            // 
            // chktm1pl2
            // 
            this.chktm1pl2.AutoSize = true;
            this.chktm1pl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chktm1pl2.Location = new System.Drawing.Point(22, 96);
            this.chktm1pl2.Name = "chktm1pl2";
            this.chktm1pl2.Size = new System.Drawing.Size(152, 33);
            this.chktm1pl2.TabIndex = 0;
            this.chktm1pl2.Text = "PLAYER 2";
            this.chktm1pl2.UseVisualStyleBackColor = true;
            this.chktm1pl2.CheckedChanged += new System.EventHandler(this.chktm1pl2_CheckedChanged);
            // 
            // chktm1pl1
            // 
            this.chktm1pl1.AutoSize = true;
            this.chktm1pl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chktm1pl1.Location = new System.Drawing.Point(22, 47);
            this.chktm1pl1.Name = "chktm1pl1";
            this.chktm1pl1.Size = new System.Drawing.Size(152, 33);
            this.chktm1pl1.TabIndex = 0;
            this.chktm1pl1.Text = "PLAYER 1";
            this.chktm1pl1.UseVisualStyleBackColor = true;
            this.chktm1pl1.CheckedChanged += new System.EventHandler(this.chktm1pl1_CheckedChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.AutoSize = true;
            this.groupBox3.BackColor = System.Drawing.Color.Plum;
            this.groupBox3.Controls.Add(this.chktm2pl5);
            this.groupBox3.Controls.Add(this.chktm2pl4);
            this.groupBox3.Controls.Add(this.chktm2pl3);
            this.groupBox3.Controls.Add(this.chktm2pl2);
            this.groupBox3.Controls.Add(this.chktm2pl1);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(568, 106);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(228, 316);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Team 2";
            // 
            // chktm2pl5
            // 
            this.chktm2pl5.AutoSize = true;
            this.chktm2pl5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chktm2pl5.Location = new System.Drawing.Point(21, 240);
            this.chktm2pl5.Name = "chktm2pl5";
            this.chktm2pl5.Size = new System.Drawing.Size(166, 33);
            this.chktm2pl5.TabIndex = 0;
            this.chktm2pl5.Text = "PLAYER 10";
            this.chktm2pl5.UseVisualStyleBackColor = true;
            this.chktm2pl5.CheckedChanged += new System.EventHandler(this.chktm2pl5_CheckedChanged);
            // 
            // chktm2pl4
            // 
            this.chktm2pl4.AutoSize = true;
            this.chktm2pl4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chktm2pl4.Location = new System.Drawing.Point(21, 188);
            this.chktm2pl4.Name = "chktm2pl4";
            this.chktm2pl4.Size = new System.Drawing.Size(152, 33);
            this.chktm2pl4.TabIndex = 0;
            this.chktm2pl4.Text = "PLAYER 9";
            this.chktm2pl4.UseVisualStyleBackColor = true;
            this.chktm2pl4.CheckedChanged += new System.EventHandler(this.chktm2pl4_CheckedChanged);
            // 
            // chktm2pl3
            // 
            this.chktm2pl3.AutoSize = true;
            this.chktm2pl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chktm2pl3.Location = new System.Drawing.Point(21, 142);
            this.chktm2pl3.Name = "chktm2pl3";
            this.chktm2pl3.Size = new System.Drawing.Size(152, 33);
            this.chktm2pl3.TabIndex = 0;
            this.chktm2pl3.Text = "PLAYER 8";
            this.chktm2pl3.UseVisualStyleBackColor = true;
            this.chktm2pl3.CheckedChanged += new System.EventHandler(this.chktm2pl3_CheckedChanged);
            // 
            // chktm2pl2
            // 
            this.chktm2pl2.AutoSize = true;
            this.chktm2pl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chktm2pl2.Location = new System.Drawing.Point(24, 93);
            this.chktm2pl2.Name = "chktm2pl2";
            this.chktm2pl2.Size = new System.Drawing.Size(152, 33);
            this.chktm2pl2.TabIndex = 0;
            this.chktm2pl2.Text = "PLAYER 7";
            this.chktm2pl2.UseVisualStyleBackColor = true;
            this.chktm2pl2.CheckedChanged += new System.EventHandler(this.chktm2pl2_CheckedChanged);
            // 
            // chktm2pl1
            // 
            this.chktm2pl1.AutoSize = true;
            this.chktm2pl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chktm2pl1.Location = new System.Drawing.Point(23, 47);
            this.chktm2pl1.Name = "chktm2pl1";
            this.chktm2pl1.Size = new System.Drawing.Size(152, 33);
            this.chktm2pl1.TabIndex = 0;
            this.chktm2pl1.Text = "PLAYER 6";
            this.chktm2pl1.UseVisualStyleBackColor = true;
            this.chktm2pl1.CheckedChanged += new System.EventHandler(this.chktm2pl1_CheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.AutoSize = true;
            this.groupBox4.BackColor = System.Drawing.Color.Plum;
            this.groupBox4.Controls.Add(this.chktm3pl5);
            this.groupBox4.Controls.Add(this.chktm3pl4);
            this.groupBox4.Controls.Add(this.chktm3pl3);
            this.groupBox4.Controls.Add(this.chktm3pl2);
            this.groupBox4.Controls.Add(this.chktm3pl1);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(318, 428);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(244, 358);
            this.groupBox4.TabIndex = 6;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Team 3";
            // 
            // chktm3pl5
            // 
            this.chktm3pl5.AutoSize = true;
            this.chktm3pl5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chktm3pl5.Location = new System.Drawing.Point(21, 277);
            this.chktm3pl5.Name = "chktm3pl5";
            this.chktm3pl5.Size = new System.Drawing.Size(166, 33);
            this.chktm3pl5.TabIndex = 0;
            this.chktm3pl5.Text = "PLAYER 15";
            this.chktm3pl5.UseVisualStyleBackColor = true;
            this.chktm3pl5.CheckedChanged += new System.EventHandler(this.chktm3pl5_CheckedChanged);
            // 
            // chktm3pl4
            // 
            this.chktm3pl4.AutoSize = true;
            this.chktm3pl4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chktm3pl4.Location = new System.Drawing.Point(22, 225);
            this.chktm3pl4.Name = "chktm3pl4";
            this.chktm3pl4.Size = new System.Drawing.Size(166, 33);
            this.chktm3pl4.TabIndex = 0;
            this.chktm3pl4.Text = "PLAYER 14";
            this.chktm3pl4.UseVisualStyleBackColor = true;
            this.chktm3pl4.CheckedChanged += new System.EventHandler(this.chktm3pl4_CheckedChanged);
            // 
            // chktm3pl3
            // 
            this.chktm3pl3.AutoSize = true;
            this.chktm3pl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chktm3pl3.Location = new System.Drawing.Point(24, 167);
            this.chktm3pl3.Name = "chktm3pl3";
            this.chktm3pl3.Size = new System.Drawing.Size(166, 33);
            this.chktm3pl3.TabIndex = 0;
            this.chktm3pl3.Text = "PLAYER 13";
            this.chktm3pl3.UseVisualStyleBackColor = true;
            this.chktm3pl3.CheckedChanged += new System.EventHandler(this.chktm3pl3_CheckedChanged);
            // 
            // chktm3pl2
            // 
            this.chktm3pl2.AutoSize = true;
            this.chktm3pl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chktm3pl2.Location = new System.Drawing.Point(21, 111);
            this.chktm3pl2.Name = "chktm3pl2";
            this.chktm3pl2.Size = new System.Drawing.Size(166, 33);
            this.chktm3pl2.TabIndex = 0;
            this.chktm3pl2.Text = "PLAYER 12";
            this.chktm3pl2.UseVisualStyleBackColor = true;
            this.chktm3pl2.CheckedChanged += new System.EventHandler(this.chktm3pl2_CheckedChanged);
            // 
            // chktm3pl1
            // 
            this.chktm3pl1.AutoSize = true;
            this.chktm3pl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chktm3pl1.Location = new System.Drawing.Point(22, 62);
            this.chktm3pl1.Name = "chktm3pl1";
            this.chktm3pl1.Size = new System.Drawing.Size(166, 33);
            this.chktm3pl1.TabIndex = 0;
            this.chktm3pl1.Text = "PLAYER 11";
            this.chktm3pl1.UseVisualStyleBackColor = true;
            this.chktm3pl1.CheckedChanged += new System.EventHandler(this.chktm3pl1_CheckedChanged);
            // 
            // groupBox5
            // 
            this.groupBox5.AutoSize = true;
            this.groupBox5.BackColor = System.Drawing.Color.Plum;
            this.groupBox5.Controls.Add(this.chktm4pl5);
            this.groupBox5.Controls.Add(this.chktm4pl4);
            this.groupBox5.Controls.Add(this.chktm4pl3);
            this.groupBox5.Controls.Add(this.chktm4pl2);
            this.groupBox5.Controls.Add(this.chktm4pl1);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(568, 428);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(228, 358);
            this.groupBox5.TabIndex = 7;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Team 4";
            // 
            // chktm4pl5
            // 
            this.chktm4pl5.AutoSize = true;
            this.chktm4pl5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chktm4pl5.Location = new System.Drawing.Point(21, 277);
            this.chktm4pl5.Name = "chktm4pl5";
            this.chktm4pl5.Size = new System.Drawing.Size(166, 33);
            this.chktm4pl5.TabIndex = 0;
            this.chktm4pl5.Text = "PLAYER 20";
            this.chktm4pl5.UseVisualStyleBackColor = true;
            this.chktm4pl5.CheckedChanged += new System.EventHandler(this.chktm4pl5_CheckedChanged);
            // 
            // chktm4pl4
            // 
            this.chktm4pl4.AutoSize = true;
            this.chktm4pl4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chktm4pl4.Location = new System.Drawing.Point(21, 225);
            this.chktm4pl4.Name = "chktm4pl4";
            this.chktm4pl4.Size = new System.Drawing.Size(166, 33);
            this.chktm4pl4.TabIndex = 0;
            this.chktm4pl4.Text = "PLAYER 19";
            this.chktm4pl4.UseVisualStyleBackColor = true;
            this.chktm4pl4.CheckedChanged += new System.EventHandler(this.chktm4pl4_CheckedChanged);
            // 
            // chktm4pl3
            // 
            this.chktm4pl3.AutoSize = true;
            this.chktm4pl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chktm4pl3.Location = new System.Drawing.Point(21, 167);
            this.chktm4pl3.Name = "chktm4pl3";
            this.chktm4pl3.Size = new System.Drawing.Size(166, 33);
            this.chktm4pl3.TabIndex = 0;
            this.chktm4pl3.Text = "PLAYER 18";
            this.chktm4pl3.UseVisualStyleBackColor = true;
            this.chktm4pl3.CheckedChanged += new System.EventHandler(this.chktm4pl3_CheckedChanged);
            // 
            // chktm4pl2
            // 
            this.chktm4pl2.AutoSize = true;
            this.chktm4pl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chktm4pl2.Location = new System.Drawing.Point(21, 111);
            this.chktm4pl2.Name = "chktm4pl2";
            this.chktm4pl2.Size = new System.Drawing.Size(166, 33);
            this.chktm4pl2.TabIndex = 0;
            this.chktm4pl2.Text = "PLAYER 17";
            this.chktm4pl2.UseVisualStyleBackColor = true;
            this.chktm4pl2.CheckedChanged += new System.EventHandler(this.chktm4pl2_CheckedChanged);
            // 
            // chktm4pl1
            // 
            this.chktm4pl1.AutoSize = true;
            this.chktm4pl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chktm4pl1.Location = new System.Drawing.Point(21, 62);
            this.chktm4pl1.Name = "chktm4pl1";
            this.chktm4pl1.Size = new System.Drawing.Size(166, 33);
            this.chktm4pl1.TabIndex = 0;
            this.chktm4pl1.Text = "PLAYER 16";
            this.chktm4pl1.UseVisualStyleBackColor = true;
            this.chktm4pl1.CheckedChanged += new System.EventHandler(this.chktm4pl1_CheckedChanged);
            // 
            // groupBox9
            // 
            this.groupBox9.AutoSize = true;
            this.groupBox9.BackColor = System.Drawing.Color.Plum;
            this.groupBox9.Controls.Add(this.lbltotalpoints);
            this.groupBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.Location = new System.Drawing.Point(3, 397);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(308, 150);
            this.groupBox9.TabIndex = 8;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Total Points";
            // 
            // lbltotalpoints
            // 
            this.lbltotalpoints.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbltotalpoints.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotalpoints.Location = new System.Drawing.Point(21, 57);
            this.lbltotalpoints.Name = "lbltotalpoints";
            this.lbltotalpoints.Size = new System.Drawing.Size(281, 54);
            this.lbltotalpoints.TabIndex = 1;
            this.lbltotalpoints.Text = "120";
            this.lbltotalpoints.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox6
            // 
            this.groupBox6.AutoSize = true;
            this.groupBox6.BackColor = System.Drawing.Color.Coral;
            this.groupBox6.Controls.Add(this.lblt1ts);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(842, 106);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(249, 136);
            this.groupBox6.TabIndex = 9;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Team 1 Total Score";
            // 
            // lblt1ts
            // 
            this.lblt1ts.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblt1ts.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblt1ts.Location = new System.Drawing.Point(23, 57);
            this.lblt1ts.Name = "lblt1ts";
            this.lblt1ts.Size = new System.Drawing.Size(170, 54);
            this.lblt1ts.TabIndex = 1;
            this.lblt1ts.Text = "0";
            this.lblt1ts.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblt1ts.Click += new System.EventHandler(this.lblt1ts_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.AutoSize = true;
            this.groupBox7.BackColor = System.Drawing.Color.Coral;
            this.groupBox7.Controls.Add(this.lblt2ts);
            this.groupBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.Location = new System.Drawing.Point(842, 248);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(249, 143);
            this.groupBox7.TabIndex = 10;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Team 2 Total Score";
            // 
            // lblt2ts
            // 
            this.lblt2ts.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblt2ts.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblt2ts.Location = new System.Drawing.Point(23, 57);
            this.lblt2ts.Name = "lblt2ts";
            this.lblt2ts.Size = new System.Drawing.Size(178, 54);
            this.lblt2ts.TabIndex = 1;
            this.lblt2ts.Text = "0";
            this.lblt2ts.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox8
            // 
            this.groupBox8.AutoSize = true;
            this.groupBox8.BackColor = System.Drawing.Color.Coral;
            this.groupBox8.Controls.Add(this.lblt3ts);
            this.groupBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.Location = new System.Drawing.Point(842, 397);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(249, 136);
            this.groupBox8.TabIndex = 11;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Team 3 Total Score";
            // 
            // lblt3ts
            // 
            this.lblt3ts.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblt3ts.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblt3ts.Location = new System.Drawing.Point(29, 57);
            this.lblt3ts.Name = "lblt3ts";
            this.lblt3ts.Size = new System.Drawing.Size(172, 54);
            this.lblt3ts.TabIndex = 1;
            this.lblt3ts.Text = "0";
            this.lblt3ts.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox10
            // 
            this.groupBox10.AutoSize = true;
            this.groupBox10.BackColor = System.Drawing.Color.Coral;
            this.groupBox10.Controls.Add(this.lblt4ts);
            this.groupBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox10.Location = new System.Drawing.Point(842, 539);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(249, 147);
            this.groupBox10.TabIndex = 12;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Team 4 Total Score";
            // 
            // lblt4ts
            // 
            this.lblt4ts.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblt4ts.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblt4ts.Location = new System.Drawing.Point(54, 57);
            this.lblt4ts.Name = "lblt4ts";
            this.lblt4ts.Size = new System.Drawing.Size(158, 54);
            this.lblt4ts.TabIndex = 1;
            this.lblt4ts.Text = "0";
            this.lblt4ts.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnIndividual
            // 
            this.btnIndividual.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIndividual.Location = new System.Drawing.Point(1126, 423);
            this.btnIndividual.Name = "btnIndividual";
            this.btnIndividual.Size = new System.Drawing.Size(250, 110);
            this.btnIndividual.TabIndex = 6;
            this.btnIndividual.Text = "Individual";
            this.btnIndividual.UseVisualStyleBackColor = true;
            this.btnIndividual.Click += new System.EventHandler(this.btnIndividual_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.ForestGreen;
            this.ClientSize = new System.Drawing.Size(1408, 825);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.TotalPoints);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.btnIndividual);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnOverallPoints);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.TotalPoints.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblshotput;
        private System.Windows.Forms.Label lblmentalmath;
        private System.Windows.Forms.Label lblSwimming;
        private System.Windows.Forms.Label lblLongJump;
        private System.Windows.Forms.Label lblRunning;
        private System.Windows.Forms.CheckBox chkshotput;
        private System.Windows.Forms.CheckBox chkmentalmath;
        private System.Windows.Forms.CheckBox chkSwimming;
        private System.Windows.Forms.CheckBox chkLongJump;
        private System.Windows.Forms.CheckBox chkRunning;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox chktm1pl5;
        private System.Windows.Forms.CheckBox chktm1pl4;
        private System.Windows.Forms.CheckBox chktm1pl3;
        private System.Windows.Forms.CheckBox chktm1pl2;
        private System.Windows.Forms.CheckBox chktm1pl1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox chktm2pl5;
        private System.Windows.Forms.CheckBox chktm2pl4;
        private System.Windows.Forms.CheckBox chktm2pl3;
        private System.Windows.Forms.CheckBox chktm2pl2;
        private System.Windows.Forms.CheckBox chktm2pl1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.CheckBox chktm3pl5;
        private System.Windows.Forms.CheckBox chktm3pl4;
        private System.Windows.Forms.CheckBox chktm3pl3;
        private System.Windows.Forms.CheckBox chktm3pl2;
        private System.Windows.Forms.CheckBox chktm3pl1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.CheckBox chktm4pl5;
        private System.Windows.Forms.CheckBox chktm4pl4;
        private System.Windows.Forms.CheckBox chktm4pl3;
        private System.Windows.Forms.CheckBox chktm4pl2;
        private System.Windows.Forms.CheckBox chktm4pl1;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label lbltotalpoints;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label lblt1ts;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label lblt2ts;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label lblt3ts;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label lblt4ts;
        private System.Windows.Forms.GroupBox TotalPoints;
        private System.Windows.Forms.Label lblOutput;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnOverallPoints;
        private System.Windows.Forms.Button btnIndividual;
    }
}

